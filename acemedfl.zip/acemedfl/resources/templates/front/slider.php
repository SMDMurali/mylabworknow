<div id="main-banner" class="owl-carousel main-banner">

				<div class="item">
					<img src="images/banner-img3.jpg" alt="" title="">
					<div class="slider-caption">
						<p>My Lab <span>technology</span> for</p><br/>
						<p>better <span>healthcare</span></p>
					</div>
				</div>

				<div class="item">
					<img src="images/banner-img2.jpg" alt="" title="">
					<div class="slider-caption">
						<p>better <span>technology</span> for</p><br/>
						<p>better <span>healthcare</span></p>
					</div>
				</div>

				<div class="item">
					<img src="images/banner-img.jpg" alt="" title="">
					<div class="slider-caption">
						<p>better <span>technology</span> for</p><br/>
						<p>better <span>healthcare</span></p>
					</div>
				</div>

				<div class="item">
					<img src="images/banner-img4.jpg" alt="" title="">
					<div class="slider-caption">
						<p>better <span>technology</span> for</p><br/>
						<p>better <span>healthcare</span></p>
					</div>
				</div>

			</div>