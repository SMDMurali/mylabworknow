<div class="sidebar-widget clearfix">

                               

								<h2 class="bordered light">Categories</h2>
                                <ul class="tags">
                                <?php   

                               get_categories();

                               
                                    ?>
								
                                </ul>
							</div>
                               

									<!-- <li><a href="mens-health.php">Men's Health</a></li>
									<li><a href="womens-health.php">Women’s Health</a></li>
									<li><a href="heart-health.php">Heart Health</a></li>
									<li><a href="liver-health.php">Liver Health</a></li>
									<li><a href="kidney-health.php">Kidney Health</a></li> -->
									<!-- <li><a href="#.">Eye Specialist</a></li>
									<li><a href="#.">Premium Wordpress</a></li>
									<li><a href="#.">Photoshop Special</a></li> -->
							