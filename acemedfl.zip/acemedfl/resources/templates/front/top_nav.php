<div class="navbar-header">
							
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#primary-nav">
							  <span class="sr-only">Toggle navigation</span>
							  <span class="icon-bar"></span>
							  <span class="icon-bar"></span>
							  <span class="icon-bar"></span>
							</button>
							
							<a class="navbar-brand" href="index.php">My Lab Work Now</a>
						
						</div>
					
						
						<div class="collapse navbar-collapse navbar-right" id="primary-nav">
							
							<ul class="nav navbar-nav">
								
								<!-- <li class="dropdown active">
									<a href="index.php" class="dropdown-toggle" data-toggle="dropdown">Home</a>						
									<ul class="dropdown-menu">                                                                                          
										<li><a href="index.html">Home Page One <label>new</label></a></li>
										<li><a href="index2.html">Home Page Two</a></li>
										<li><a href="index3.html">Home Page Three</a></li>
										<li><a href="index4.html">Home Page Four</a></li>
										<li><a href="index5.html">Home Page Five <label>new</label></a></li>
										<li><a href="index-loader.html">Home Page Loader <label>new</label></a></li>
									</ul>
								</li> -->
								<li class="<?php if($page== 'index.php'):echo 'active'; endif;?>"><a href="index.php">Home</a></li>
								<li class="<?php if($page== 'about-us2.php'):echo 'active'; endif;?>"><a href="about-us2.php">About Us</a></li>

								<!-- <li class="dropdown">
									<a href="about-us2.php" class="dropdown-toggle" data-toggle="dropdown">About Us</a>
									 <ul class="dropdown-menu">                                                                                          
									  <li><a href="about-us.html">About Us One</a></li>
									  <li><a href="about-us2.html">About Us Two</a></li>
									</ul> -->
								<!-- </li>  -->
							  
								<!-- <li class="dropdown ">
									<a href="" class="dropdown-toggle" data-toggle="dropdown">All Test</a>
									<ul class="dropdown-menu">    -->

										<!-- <li><a href="mens-health.php">Men’s Health</a></li>
										<li><a href="womens-health.php">Women’s Health</a></li>
										<li><a href="heart-health.php">Heart Health</a></li>
										<li><a href="liver-health.php">Liver Health</a></li>
										<li><a href="kidney-health.php">Kidney Health</a></li>	                                                                                        -->
										 <!-- <li><a href="patient-and-families.html">Mens Healths</a></li> -->


										 <!-- <li class="dropdown-submenu"><a href="mens-health.php">Mens Healths</a><i class="fa fa-angle-right pull-right"></i>
											<ul class="dropdown-menu">                                             <li><a href="mens-health.php">Cortisol</a></li>      
											<li><a href="mens-health.php">DHEA-s</a></li>  
											<li><a href="mens-health.php">Estradiol</a></li>  
											<li><a href="mens-health.php">Free Testosterone</a></li>
												
											 </ul>
										</li>

										<li class="dropdown-submenu"><a href="womens-health.php">Women’s Health</a><i class="fa fa-angle-right pull-right"></i>
											<ul class="dropdown-menu">                                             <li><a href="womens-health.php">Estradiol</a></li>      
											<li><a href="womens-health.php">Progesterone</a></li>  
											<li><a href="womens-health.php">Luteinizing Hormone</a></li>  
											<li><a href="womens-health.php">Follicle-Stimulating Hormone</a></li>
											<li><a href="womens-health.php">DHEAS</a></li>
											<li><a href="womens-health.php">Cortisol</a></li>
											<li><a href="womens-health.php">Thyroid-Stimulating Hormone</a></li>
											<li><a href="womens-health.php">Free T3</a></li>
											<li><a href="womens-health.php">Free T4</a></li>
											<li><a href="womens-health.php">Free Testosterone</a></li>
											<li><a href="womens-health.php">Thyroid Peroxidase Antibodies</a></li>
												
											 </ul>
										</li>
										<li class="dropdown-submenu"><a href="heart-health.php">Heart Health</a><i class="fa fa-angle-right pull-right"></i>
											<ul class="dropdown-menu">                                             
											<li><a href="heart-health.php">Total Cholesterol</a></li>
											<li><a href="heart-health.php">HDL</a></li>
											<li><a href="heart-health.php">Calculated LDL</a></li>
											<li><a href="heart-health.php">Triglycerides</a></li>
											<li><a href="heart-health.php">hs-CRP</a></li>
											<li><a href="heart-health.php">HbA1c</a></li>

												
											 </ul>
										</li>
										<li class="dropdown-submenu"><a href="liver-health.php">Liver Health</a><i class="fa fa-angle-right pull-right"></i>
											<ul class="dropdown-menu">                                             <li><a href="liver-health.php">Albumin</a></li>
											<li><a href="liver-health.php">Globulin</a></li>
											<li><a href="liver-health.php">Bilirubin</a></li>
											<li><a href="liver-health.php">Alkaline Phosphatase (ALP)</a></li>
											<li><a href="liver-health.php">Gamma GT</a></li>
											<li><a href="liver-health.php">Alanine Transferase (ALT)</a></li>
												
											 </ul>
										</li>
										<li class="dropdown-submenu"><a href="kidney-health.php">Kidney Health</a><i class="fa fa-angle-right pull-right"></i>
											<ul class="dropdown-menu">                                             
											<li><a href="kidney-health.php">Urea</a></li>
											<li><a href="kidney-health.php">Creatinine</a></li>
											<li><a href="kidney-health.php">eGFR (estimated glomerular filtration rate)</a></li>

												
											 </ul>
										</li> -->

										<!--down  of ul -->
										 <!-- <li class="dropdown-submenu"><a href="#.">Medicome Trials</a><i class="fa fa-angle-right pull-right"></i>
													<ul class="dropdown-menu">  
													  <li><a href="trials.html">Trials</a></li>
													</ul>
												</li>  -->
												 <!-- <li class="dropdown-submenu"><a href="#.">Cancer Care</a><i class="fa fa-angle-right pull-right"></i>
													<ul class="dropdown-menu">  
													  <li><a href="cancer-center.html">Cancer Center</a></li>
													  <li><a href="cancer-center.html">Cell Death Research</a></li>
													  <li><a href="cancer-center.html">Brain Cancer</a></li>
													  <li><a href="cancer-center.html">Tumor Microenvironment</a></li>
													  <li><a href="cancer-center.html">Breast Cancer</a></li>
													  <li><a href="cancer-center.html">Childhood Cancers</a></li>
													  <li><a href="cancer-center.html">Endocrine Cancers</a></li>
													  <li><a href="cancer-center.html">Male Cancers</a></li>
													  <li><a href="cancer-center.html">Skin Cancer </a></li>
													</ul>
												</li>  -->
													<!-- <li class="dropdown-submenu"><a href="#.">Childrens Health</a><i class="fa fa-angle-right pull-right"></i>
														<ul class="dropdown-menu">  
															<li><a href="children-health.html"> Genetic Disease</a></li>
															<li><a href="children-health.html"> Growth &amp; Development</a></li>
															<li><a href="children-health.html"> Infections</a></li>
															<li><a href="children-health.html"> Pregnancy &amp; Baby</a></li>
															<li><a href="children-health.html"> Nutrition &amp; Fitness</a></li>
															<li><a href="children-health.html"> Emotions &amp; Behavior</a></li>
															<li><a href="children-health.html"> Doctors &amp; Hospitals</a></li>
															<li><a href="children-health.html"> Muscle Development</a></li>
															<li><a href="children-health.html"> RNA Biology</a></li>
														</ul>
													</li>  -->

													<!--up of ul -->
											
									 <!-- <li class="dropdown-submenu"><a href="#">Portfolio</a><i class="fa fa-angle-right pull-right"></i>
											<ul class="dropdown-menu">
												<li><a href="gallery1.html">Portfolio one</a></li>
												<li><a href="gallery2.html">Portfolio two</a></li>
												<li><a href="gallery3.html">Portfolio three</a></li>
											</ul>
										</li>  -->
										<!-- <li><a href="services.html">Services</a></li>
										<li><a href="shortcodes.html">Shortcodes</a></li>
										<li><a href="error404.html">404 Not Found</a></li> -->
									<!-- </ul>
								</li> -->
							  
							  	<li class="dropdown">
									<a href="" class="dropdown-toggle" data-toggle="dropdown">All Test</a>
									<ul class="dropdown-menu">   

								<?php	get_categories(); ?>
										
										<!-- <li class=""><a href="my-account.php">Mens Health</a></li>  
										<li class=""><a href="add-patient.php">Women's Health</a></li>         
										<li class=""><a href="kit-register.php">Heart Health</a></li>                   
										<li class=""><a href="kit-register.php">Liver Health</a></li>
										<li class=""><a href="order-history.php">Kidney Health</a></li> -->
											
									</ul>
								</li> 
								<!-- <li class="mega-menu-item dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">DEPARTMENTS</a>
									<div class="mega-menu dropdown-menu">
										<img src="images/mega-menu-img.jpg" class="img-rounded" alt="" title="">
										<ul>
											<li><strong>Department One</strong></li>
											<li><a href="medical-department.html">Medical Department</a></li>
											<li><a href="medical-department.html">Body Lift Department</a></li>
											<li><a href="medical-department.html">Liposuction Department</a></li>
											<li><a href="medical-department.html">Eyelid Department</a></li>
											<li><a href="medical-department.html">Thigh Lift Department</a></li>
											<li><a href="medical-department.html">Brow Lift Department</a></li>
										</ul>
										<ul>
											<li><strong>Department Two</strong></li>
											<li><a href="medical-department.html">Arm Lift Department</a></li>
											<li><a href="medical-department.html">Rhinoplasty Department</a></li>
											<li><a href="medical-department.html">Ear Surgery Department</a></li>
											<li><a href="medical-department.html">Tummy Tuck Department</a></li>
											<li><a href="medical-department.html">Neck Lift Department</a></li>
										</ul>
										<ul>
											<li><strong>Department Three</strong></li>
											<li><a href="medical-department.html">Arm Lift Department</a></li>
											<li><a href="medical-department.html">Rhinoplasty Department</a></li>
											<li><a href="medical-department.html">Ear Surgery Department</a></li>
											<li><a href="medical-department.html">Rhinoplasty Department</a></li>
										</ul>
									</div>
								</li> -->
							  
								<!-- <li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">Gallery</a>
									<ul class="dropdown-menu">                                                                                          
										<li><a href="gallery1.html">Gallery one</a></li>
										<li><a href="gallery2.html">Gallery two</a></li>
										<li><a href="gallery3.html">Gallery three</a></li>
									</ul>
								</li> -->
							  
								<!-- <li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">blog</a>
									<ul class="dropdown-menu">                                                                                          
										<li><a href="blog.html">Blog one</a></li>
										<li><a href="blog-single-post.html">Blog two</a></li>
										<li><a href="blog-2-column.html">Blog three</a></li>
										<li><a href="blog-detail.html">Blog Detail</a></li>
									</ul>
								</li> -->
							  
								<!-- <li class="dropdown last ">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">Shop</a>
									<ul class="dropdown-menu">                                                                                          
										
										<li><a href="shop-detail.php">Shop detail</a></li>
										<li><a href="shopping-cart.php">Shoping cart</a></li>
									</ul>
								</li> -->
							  
								<!-- <li class="dropdown last">
									<a href="contact-us2.php" class="dropdown-toggle" data-toggle="dropdown">Contact Us</a>
									<ul class="dropdown-menu">                                                                                          
										<li><a href="contact-us.html">Contact Us one</a></li>
										<li><a href="contact-us2.html">Contact Us two</a></li>
									</ul>
								</li> -->

								<li class="<?php if($page== 'shop.php'):echo 'active'; endif;?>"><a href="shop.php">Shop</a></li>
								<li class="<?php if($page== 'contact-us2.php'):echo 'active'; endif;?>"><a href="contact-us2.php">Contact</a></li>
								<li class="<?php if($page== 'shopping-cart.php'):echo 'active'; endif;?>"><a href="shopping-cart.php"><i class="fa fa-shopping-cart"></i></a></li>
								
								<li class=""><a href="login.php">Login</a></li>


							
								<!-- <li class="dropdown">
									<a href="" class="dropdown-toggle" data-toggle="dropdown">My Account</a>
									<ul class="dropdown-menu">   
										<li><p>Welcome <strong></strong></p></li>
										<li class=""><a href="my-account.php">My Account</a></li>  
										<li class=""><a href="add-patient.php">Add Patient</a></li>                            
										<li class=""><a href="kit-register.php">Kit Registration <label>Active</label></a></li>
										<li class=""><a href="order-history.php">Order History</a></li>
											
									</ul>
								</li>  -->
							</ul>
							
						</div>