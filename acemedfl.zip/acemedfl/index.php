<?php require_once ("resources/config.php") ?> 

  	<!-- notification message -->
  



			<!-- Header
			============================================= -->
			<?php include(TEMPLATE_FRONT . DS . "header.php");  ?>

			<!-- Main Banner
			============================================= -->
			
			<?php include(TEMPLATE_FRONT . DS . "slider.php");  ?>

		<div class="clearfix"></div>

		<div id="content-index">

		<div class="container" >

					<div class="row" style="margin-top: 30px;">

		<div class="col-md-12 clearfix">
							

							<!-- Products
							============================================= -->
							<h2 class="bordered light">Popular <span>Test</span></h2>

							

							<div class="products">

							<?php get_products();  ?>

								

							</div>

						</div>

					</div>
		</div>


			<!-- Services
			============================================= -->
			<section class="services-sec container">

				<div class="service-box one">
					<span class="icon img-circle"><i class="fa fa-lightbulb-o"></i></span>
					<h4><a href="#.">creative doctors</a></h4>
					<p>If you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing elit. Ut volutpat eros  adipiscing elit Ut volutpat. cancer care is power of dummy for all business.</p>
				</div>

				<div class="service-box two">
					<span class="icon img-circle"><i class="fa fa fa-flask"></i></span>
					<h4><a href="#.">creative doctors</a></h4>
					<p>If you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing elit. Ut volutpat eros  adipiscing elit Ut volutpat. cancer care is power of dummy for all business.</p>
				</div>

				<div class="service-box three">
					<span class="icon img-circle"><i class="fa fa-tint"></i></span>
					<h4><a href="#.">creative doctors</a></h4>
					<p>If you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing elit. Ut volutpat eros  adipiscing elit Ut volutpat. cancer care is power of dummy for all business.</p>
				</div>

				<div class="service-box four">
					<span class="icon img-circle"><i class="fa fa-phone"></i></span>
					<h4><a href="#.">creative doctors</a></h4>
					<p>If you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing elit. Ut volutpat eros  adipiscing elit Ut volutpat. cancer care is power of dummy for all business.</p>
				</div>

			</section>


			<!-- News and Our Clinic
			============================================= -->
			<section class="news-and-our-clinic">

				<div class="container">

					<div class="row">

						<div class="col-md-7">

							<div class="latest-news2">

								<h2 class="light bordered">Latest <span>News</span></h2>

								<ul id="latest-news-carousel" class="jcarousel-skin-tango blog-style2 list-unstyled">

									<li>
										<i class="post-icon img-circle fa fa-picture-o"></i>
										<article class="blog2-item">
											<div class="blog2-thumbnail">
											<img src="images/blog2-img1.jpg" alt="">
											</div>
											<div class="blog2-content">
											<span class="arrow-right"></span>
											<h4 class="blog2-title"><a href="#">Latest Blog Graphic Image Post</a></h4>
											<p class="post-date">10 December, 2013 - 18:33:04</p>
											<p>Printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever scrambled...<a class="#." href="#.">READ MORE</a></p>

											</div>
										</article>
									</li>

									<li>
										<i class="post-icon img-circle fa fa-video-camera"></i>
										<article class="blog2-item">
											<div class="blog2-thumbnail">
											<img src="images/blog2-img2.jpg" alt="">
											</div>
											<div class="blog2-content">
											<span class="arrow-right"></span>
											<h4 class="blog2-title"><a href="#">Latest Blog Graphic Image Post</a></h4>
											<p class="post-date">10 December, 2013 - 18:33:04</p>
											<p>Printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever scrambled...<a class="#." href="#.">READ MORE</a></p>

											</div>
										</article>
									</li>

									<li>
										<i class="post-icon img-circle fa fa-picture-o"></i>
										<article class="blog2-item">
											<div class="blog2-thumbnail">
											<img src="images/blog2-img3.jpg" alt="">
											</div>
											<div class="blog2-content">
											<span class="arrow-right"></span>
											<h4 class="blog2-title"><a href="#">Latest Blog Graphic Image Post</a></h4>
											<p class="post-date">10 December, 2013 - 18:33:04</p>
											<p>Printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever scrambled...<a class="#." href="#.">READ MORE</a></p>

											</div>
										</article>
									</li>

									<li>
										<i class="post-icon img-circle fa fa-picture-o"></i>
										<article class="blog2-item">
											<div class="blog2-thumbnail">
											<img src="images/blog2-img1.jpg" alt="">
											</div>
											<div class="blog2-content">
											<span class="arrow-right"></span>
											<h4 class="blog2-title"><a href="#">Latest Blog Graphic Image Post</a></h4>
											<p class="post-date">10 December, 2013 - 18:33:04</p>
											<p>Printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever scrambled...<a class="#." href="#.">READ MORE</a></p>

											</div>
										</article>
									</li>

									<li>
										<i class="post-icon img-circle fa fa-video-camera"></i>
										<article class="blog2-item">
											<div class="blog2-thumbnail">
											<img src="images/blog2-img2.jpg" alt="">
											</div>
											<div class="blog2-content">
											<span class="arrow-right"></span>
											<h4 class="blog2-title"><a href="#">Latest Blog Graphic Image Post</a></h4>
											<p class="post-date">10 December, 2013 - 18:33:04</p>
											<p>Printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever scrambled...<a class="#." href="#.">READ MORE</a></p>

											</div>
										</article>
									</li>

								</ul>

							</div>

						</div>

						<div class="col-md-5">

							<h2 class="light bordered">our <span>Clinic</span></h2>

							<div id="our-clinic" class="slider-mini owl-carousel">

								<div class="item">
									<img src="images/mini-slider-img.jpg" alt="" title="">
									<h4>Main office</h4>
									<p>If you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing elit. Ut volutpat eros  adipiscing elit Ut volutpat. cancer care is power of dummy for all business.</p>
									<a href="#." class="btn-rounded btn-bordered">View All</a>
								</div>

								<div class="item">
									<img src="images/mini-slider-img2.jpg" alt="" title="">
									<h4>Main office</h4>
									<p>If you need a doctor for to consectetuer Lorem ipsum dolor, consectetur adipiscing elit. Ut volutpat eros  adipiscing elit Ut volutpat. cancer care is power of dummy for all business.</p>
									<a href="#." class="btn-rounded btn-bordered">View All</a>
								</div>

							</div>

						</div>

					</div>

				</div>

			</section>



			<!-- Video
			============================================= -->
			<section class="video">

				<div class="video-overlay"></div>

				<figure>
					<iframe src="http://player.vimeo.com/video/25708134?autoplay=1?title=0&amp;byline=0&amp;portrait=0" width="400" height="225"></iframe>
				</figure>

				<div class="container">
					<div class="video-inner-content text-center">
						<h1>looking for professional design</h1>
						<p class="lead">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod Donec ipsum diam, pretium mollis laoreet dolore magna aliquam erat volutpat.</p>
						<a href="#." class="btn btn-default btn-rounded">$15 buy now</a>
					</div>
				</div>

			</section>




			<!-- Medicom Tour and Appointment
			============================================= -->
			<div class="container">

				<div class="row">

					<div class="col-md-7">

						<h2 class="light bordered">My Lab Work Now<span>tour</span></h2>

						<div class="panel-group" id="accordion">

						  <div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title active">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
								  <span><i class="fa fa-plus fa-minus"></i></span>Outpatient Rehabilitation
								</a>
							  </h4>
							</div>
							<div id="collapseFive" class="panel-collapse collapse in">
							  <div class="panel-body">
								It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Aldus.
		Page Maker including versions.
								<br><br>
								It has release of Letraset sheets containing Lorem Aldus.
		Page Maker including versions Letraset sheets containing Lorem Aldus heets containing Lorem Aldus.
		Page Maker including versions Letraset sheets containing.
		Page Maker including versions.

							  </div>
							</div>
						  </div>

						  <div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
								  <span><i class="fa fa-plus"></i></span>Dental Instruments
								</a>
							  </h4>
							</div>
							<div id="collapseSix" class="panel-collapse collapse">
							  <div class="panel-body">
							   It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Aldus.
		Page Maker including versions.
								<br><br>
								It has release of Letraset sheets containing Lorem Aldus.
		Page Maker including versions Letraset sheets containing Lorem Aldus heets containing Lorem Aldus.
		Page Maker including versions Letraset sheets containing.
		Page Maker including versions.
							  </div>
							</div>
						  </div>

						  <div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseSeven">
								  <span><i class="fa fa-plus"></i></span>Outpatient Rehabilitation
								</a>
							  </h4>
							</div>
							<div id="collapseSeven" class="panel-collapse collapse">
							  <div class="panel-body">
								It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Aldus.
		Page Maker including versions.
								<br><br>
								It has release of Letraset sheets containing Lorem Aldus.
		Page Maker including versions Letraset sheets containing Lorem Aldus heets containing Lorem Aldus.
		Page Maker including versions Letraset sheets containing.
		Page Maker including versions.
							  </div>
							</div>
						  </div>

						</div>

						<div class="testimonials2">

							<h2 class="light bordered">What our <span>patients say</span></h2>

							<div id="carousel-testimonials2" class="owl-carousel">

								<div class="item">
								  <div class="testimonials2-img"><img src="images/patient-img.png" class="img-circle img-thumbnail" alt="" title=""></div>
								  <div class="testimonials2-content">
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Nam vitae felis dolor in malesuada fermentum.</p>
									<p class="testimonials2-patient-detail"><span>John Smith,</span> Heart patient</p>
								  </div>
								</div>

								<div class="item">
								  <div class="testimonials2-img"><img src="images/patient-img.png" class="img-circle img-thumbnail" alt="" title=""></div>
								  <div class="testimonials2-content">
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Nam vitae felis dolor in malesuada fermentum.</p>
									<p class="testimonials2-patient-detail"><span>John Smith,</span> Heart patient</p>
								  </div>
								</div>

								<div class="item">
								  <div class="testimonials2-img"><img src="images/patient-img.png" class="img-circle img-thumbnail" alt="" title=""></div>
								  <div class="testimonials2-content">
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Nam vitae felis dolor in malesuada fermentum.</p>
									<p class="testimonials2-patient-detail"><span>John Smith,</span> Heart patient</p>
								  </div>
								</div>

							</div>

						</div>

					</div>

					<div class="col-md-5">

						<h2 class="light bordered">make an <span>appointment</span></h2>

						<div class="appointment-sec2 clearfix">

							<div class="success" id="message-app" style="display:none;"></div>

							<form name="appoint_form" id="appoint_form" method="post" action="submit.php" onSubmit="return false">
								<label>First Name:</label>
								<input type="text" name="app_fname" id="app_fname" placeholder="First Name" onKeyPress="removeChecks();">

								<label>Last Name:</label>
								<input type="text" name="app_lname" id="app_lname" placeholder="Last Name" onKeyPress="removeChecks();">

								<label>Email Address:</label>
								<input type="email" name="app_email_address" id="app_email_address" placeholder="Email Address" onKeyPress="removeChecks();">

								<label>Phone No:</label>
								<input type="text" name="app_phone" id="app_phone" placeholder="Phone No">

								<label>Meeting Date:</label>
								<input type="text" name="datepicker" id="datepicker" placeholder="11-12-2013" onClick="removeChecks();">
								<label>Patient:</label>
								<select name="gender" id="gender">
									<option>Male</option>
									<option>Female</option>
									<option>Child</option>
								</select>

								<label>Message:</label>
								<textarea placeholder="Message" name="app_msg" id="app_msg"></textarea>

							   <input type="submit" value="submit" class="btn btn-default btn-rounded" onClick="validateAppoint();">
							</form>

						</div>

					</div>

				</div>

			</div>


		</div><!--end #content-index-->


		<div class="height20"></div>

		<div class="colourfull-row"></div>


		<!-- Footer
		============================================= -->
		<?php include(TEMPLATE_FRONT . DS . "footer.php");  ?>

		<!-- back to top -->
		<a href="#." class="back-to-top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

    </div><!--end #wrapper-->



	<!-- All Javascript
	============================================= -->
	<script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.stellar.js"></script>
	<script src="js/jquery-ui-1.10.3.custom.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/waypoints.js"></script>
	<script src="js/jquery.uniform.js"></script>
    <script src="js/easyResponsiveTabs.js"></script>
	<script src="js/jquery.fancybox.pack.js"></script>
	<script src="js/jquery.fancybox-media.js"></script>
	<script src="js/jquery.mixitup.js"></script>
	<script src="js/forms-validation.js"></script>
	<script src="js/video.js"></script>
	<script src="js/jquery.jcarousel.min.js"></script>
	<script src="js/jquery.easypiechart.min.js"></script>
	<script src="js/scripts.js"></script>

  </body>
</html>
